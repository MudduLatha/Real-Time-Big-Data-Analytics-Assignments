import kafka.javaapi.producer.Producer;
import kafka.producer.ProducerConfig;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.storm.kafka.KeyValueSchemeAsMultiScheme;
import org.apache.storm.kafka.bolt.KafkaBolt;
import org.apache.storm.kafka.bolt.mapper.FieldNameBasedTupleToKafkaMapper;
import org.apache.storm.kafka.bolt.selector.DefaultTopicSelector;
import org.apache.storm.shade.org.json.simple.JSONObject;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Tuple;
import kafka.producer.KeyedMessage;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import static org.apache.storm.kafka.bolt.KafkaBolt.TOPIC;
import static org.omg.IOP.TAG_ORB_TYPE.value;

/**
 * Created by latha on 10/24/2016.
 */
public class ThirdBolt extends BaseRichBolt {
    public static final String TOPIC = "LabAssignment";
    //public static final String KAFKA_TOPIC_B = "lab78output";
    //public static final String KAFKA_BROKER_PROPERTIES = "kafka.broker.properties";

    private Producer<Integer, String> producer;
    OutputCollector collector;

    final Logger LOG = LoggerFactory.getLogger(StormKafkaMain.class);
/*
    String API_KEY = "fLr-gBAV6_SS8Qtf-0-MEBlfR51d2nQr";
    String DATABASE_NAME = "readvideo_realtime";
    String COLLECTION_NAME = "readvideo";
    String urlString = "https://api.mlab.com/api/1/databases/" +
            DATABASE_NAME + "/collections/" + COLLECTION_NAME + "?apiKey=" + API_KEY;
*/
    @Override
    public void prepare(Map map, TopologyContext topologyContext, OutputCollector outputCollector) {

    }

    @Override
    public void execute(Tuple tuple) {
        String key = null;

        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        props.put("acks", "1");
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

        KafkaBolt bolt = new KafkaBolt()
                .withProducerProperties(props)
                .withTopicSelector(new DefaultTopicSelector(TOPIC))
                .withTupleToKafkaMapper(new FieldNameBasedTupleToKafkaMapper());

        //if (tuple.contains(BOLT_KEY)) {
        key = (String) tuple.getStringByField("framescount");

        String message = (String) tuple.getStringByField("word");
        LOG.info("Executing Third Bolt");

        String encodedString = key + message;

        collector.emit(new Values("message", encodedString));

        TopologyBuilder builder = new TopologyBuilder();
        builder.setBolt("ProducerBolt", bolt, 8).shuffleGrouping("ThirdBolt");

/*
        try {
            URL url = new URL(urlString);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setDoOutput(true);
            urlConnection.setRequestMethod("POST");
            urlConnection.setRequestProperty("Content-Type", "application/json");
            urlConnection.setRequestProperty("Accept", "application/json");
            Writer writer = new BufferedWriter(new OutputStreamWriter(urlConnection.getOutputStream(), "UTF-8"));
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("data", encodedString);
            writer.write(jsonObject.toString());
            writer.close();
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(urlConnection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        LOG.info("MongoDB upload");

        System.out.println("Uploaded data to Mongo");
*/

    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer outputFieldsDeclarer) {

    }
}
